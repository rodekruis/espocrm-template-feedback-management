<?php

namespace Espo\Modules\FeedbackManagementTemplate\Controllers;

class CSourceLevel2 extends \Espo\Core\Templates\Controllers\Base
{}
