<?php

namespace Espo\Custom\Controllers;

class Region extends \Espo\Core\Templates\Controllers\Base
{
}
