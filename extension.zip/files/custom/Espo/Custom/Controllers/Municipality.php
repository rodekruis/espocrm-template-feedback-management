<?php

namespace Espo\Custom\Controllers;

class Municipality extends \Espo\Core\Templates\Controllers\Base
{
}
