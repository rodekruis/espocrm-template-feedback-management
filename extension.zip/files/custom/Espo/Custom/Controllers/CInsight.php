<?php

namespace Espo\Modules\FeedbackManagementTemplate\Controllers;

class CInsight extends \Espo\Core\Templates\Controllers\Base
{}
