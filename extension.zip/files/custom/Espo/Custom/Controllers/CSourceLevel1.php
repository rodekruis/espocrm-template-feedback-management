<?php

namespace Espo\Modules\FeedbackManagementTemplate\Controllers;

class CSourceLevel1 extends \Espo\Core\Templates\Controllers\Base
{}
