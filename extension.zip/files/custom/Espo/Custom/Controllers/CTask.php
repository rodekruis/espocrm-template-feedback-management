<?php

namespace Espo\Custom\Controllers;

class CTask extends \Espo\Core\Templates\Controllers\BasePlus
{
}
