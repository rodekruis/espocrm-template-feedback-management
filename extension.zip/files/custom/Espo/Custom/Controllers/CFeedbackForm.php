<?php

namespace Espo\Modules\FeedbackManagementTemplate\Controllers;

class CFeedbackForm extends \Espo\Core\Templates\Controllers\Base
{}
