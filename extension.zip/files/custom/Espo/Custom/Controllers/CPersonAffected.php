<?php

namespace Espo\Custom\Controllers;

class CPersonAffected extends \Espo\Core\Templates\Controllers\Person
{
}
