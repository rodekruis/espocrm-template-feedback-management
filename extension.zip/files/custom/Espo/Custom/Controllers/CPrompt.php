<?php

namespace Espo\Custom\Controllers;

class CPrompt extends \Espo\Core\Templates\Controllers\Base
{
}
