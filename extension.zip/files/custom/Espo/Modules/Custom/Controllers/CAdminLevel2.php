<?php

namespace Espo\Modules\Custom\Controllers;

class CAdminLevel2 extends \Espo\Core\Templates\Controllers\Base
{}
