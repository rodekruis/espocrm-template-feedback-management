<?php

namespace Espo\Modules\Custom\Controllers;

class CAdminlevel1 extends \Espo\Core\Templates\Controllers\Base
{}
