<?php

namespace Espo\Modules\Custom\Controllers;

class CCodingLevel1 extends \Espo\Core\Templates\Controllers\Base
{}
