<?php

namespace Espo\Modules\Custom\Controllers;

class CCodingLevel2 extends \Espo\Core\Templates\Controllers\Base
{}
