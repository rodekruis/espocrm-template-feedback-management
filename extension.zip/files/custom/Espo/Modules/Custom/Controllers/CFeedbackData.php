<?php

namespace Espo\Modules\Custom\Controllers;

class CFeedbackData extends \Espo\Core\Templates\Controllers\Base
{}
