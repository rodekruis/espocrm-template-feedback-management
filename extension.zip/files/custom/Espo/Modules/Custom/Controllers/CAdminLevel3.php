<?php

namespace Espo\Modules\Custom\Controllers;

class CAdminLevel3 extends \Espo\Core\Templates\Controllers\Base
{}
