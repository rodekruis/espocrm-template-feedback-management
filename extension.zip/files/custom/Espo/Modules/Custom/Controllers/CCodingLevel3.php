<?php

namespace Espo\Modules\Custom\Controllers;

class CCodingLevel3 extends \Espo\Core\Templates\Controllers\Base
{}
