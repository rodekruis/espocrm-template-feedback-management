<?php

namespace Espo\Modules\Custom\Controllers;

class CInsight extends \Espo\Core\Templates\Controllers\Base
{}
